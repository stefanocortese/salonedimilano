<?php

//CARING
function caring_taxonomy() {
	register_taxonomy(
		'caring-line',  //The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces).
		'caring',   		 //post type name
		array(
			'hierarchical' 		=> true,
			'label' 			=> 'Gamma',  //Display name
			'query_var' 		=> true,
			'rewrite'			=> array(
					'slug' 			=> 'caring-line', // This controls the base slug that will display before each term
					'with_front' 	=> false // Don't display the category base before
					)
			)
		);
}
add_action( 'init', 'caring_taxonomy');


function filter_post_type_link_caring( $link, $post) {
    if ( $post->post_type != 'caring' )
        return $link;

    if ($cats = get_the_terms( $post->ID, 'caring-line' ))
        $link = str_replace( '%caring-line%', array_pop($cats)->slug, $link );
    return $link;
}
add_filter('post_type_link', 'filter_post_type_link_caring', 10, 2);


//COLOR
function color_taxonomy() {
	register_taxonomy(
		'color-line',  //The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces).
		'color',   		 //post type name
		array(
			'hierarchical' 		=> true,
			'label' 			=> 'Gamma',  //Display name
			'query_var' 		=> true,
			'rewrite'			=> array(
					'slug' 			=> 'color-line', // This controls the base slug that will display before each term
					'with_front' 	=> false // Don't display the category base before
					)
			)
		);
}
add_action( 'init', 'color_taxonomy');


function filter_post_type_link_color( $link, $post) {
    if ( $post->post_type != 'color' )
        return $link;

    if ($cats = get_the_terms( $post->ID, 'color-line' ))
        $link = str_replace( '%color-line%', array_pop($cats)->slug, $link );
    return $link;
}
add_filter('post_type_link', 'filter_post_type_link_color', 10, 2);

//straightness
function straightness_taxonomy() {
	register_taxonomy(
		'straightness-line',  //The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces).
		'straightness',   		 //post type name
		array(
			'hierarchical' 		=> true,
			'label' 			=> 'Gamma',  //Display name
			'query_var' 		=> true,
			'rewrite'			=> array(
					'slug' 			=> 'straightness-line', // This controls the base slug that will display before each term
					'with_front' 	=> false // Don't display the category base before
					)
			)
		);
}
add_action( 'init', 'straightness_taxonomy');


function filter_post_type_link_straightness( $link, $post) {
    if ( $post->post_type != 'straightness' )
        return $link;

    if ($cats = get_the_terms( $post->ID, 'straightness-line' ))
        $link = str_replace( '%straightness-line%', array_pop($cats)->slug, $link );
    return $link;
}
add_filter('post_type_link', 'filter_post_type_link_straightness', 10, 2);

