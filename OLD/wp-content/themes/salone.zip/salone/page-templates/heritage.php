<?php
/**
 * Template Name: Heritage Page
 *
 * @package WordPress
 * @subpackage Salone_Milano
 * @since Salone Milano 1.0
 */

get_header(); ?>

<div id="main-content" class="main-content">

	<div id="primary" class="content-area">
		<div id="content" class="site-content" role="main">
		<?php

		$args = array( 'post_type' => 'heritage' );
		$loop = new WP_Query( $args );
		while ( $loop->have_posts() ) : $loop->the_post();

		?>
			<article id="post-<?php the_title(); ?>" <?php post_class(); ?>>
			
			<?php 

			$image = get_field('bg_img_heritage'); 
			$url = $image['url'];
			$alt = $image['alt'];

			?>
			
			<img src="<?php echo $url; ?>" alt="<?php echo $alt  ?>" class="bg">

				<header class="entry-header"><h1 class="entry-title">
				<?php the_field('titolo_heritage'); ?>
				</h1></header><!-- .entry-header -->

				<div class="entry-content">
					<?php the_field('paragrafo_heritage'); ?>
				</div><!-- .entry-content -->
			</article><!-- #post-## -->
		
		<?php
		endwhile;
		wp_reset_query();
		?>

		</div><!-- #content -->
	</div><!-- #primary -->
</div><!-- #main-content -->

<?php

get_footer();
