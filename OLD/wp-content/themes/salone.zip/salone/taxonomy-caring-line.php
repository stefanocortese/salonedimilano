<?php
/**
 * The template for displaying Custom Posts Caring line
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Salone_Milano
 * @since Salone Milano 1.0
 */

get_header(); ?>

	<section id="primary" class="site-content">
		<div id="content" role="main">

		<?php if ( have_posts() ) : ?>
			<header class="archive-header">
				<h1 class="archive-title">
					<?php

					//RECUPERO IL NOME DEL CUSTOM POST DI APPARTENENZA 

					$post_type = get_post_type_object( get_post_type($post) );
						
						echo $post_type->label ;

					?>
				</h1>
				<h2>

					<?php 
					
					//RECUPERO LA CATEGORIA (GAMMA) DI APPARTENENZA
					the_terms( $post->ID, $post_type->label.'-line', ' ', ' / ' ); 

					?>
				</h2>
			</header><!-- .archive-header -->

			<?php
			/* Start the Loop */
			while ( have_posts() ) : the_post();
			?>
			<article id="post-<?php the_title(); ?>" <?php post_class(); ?>>
			
			<?php 

			$image = get_field('immagine_prodotto'); 
			//$url = $image['url'];
			

			?>
			
			<img src="<?php echo $image[url]; ?>" alt="<?php the_title(); ?>" class="bg">

				<header class="entry-header"><h1 class="entry-title">
				<?php the_field('titolo_prodotto'); ?>
				</h1></header><!-- .entry-header -->

				<div class="entry-content">
					
				<?php 

					the_field('sottotitolo_prodotto');
					//STAMPO IL LINK DEL PRODOTTO
					$link  = '<a class="pulsante" href="';
					$link .=  get_permalink($post->ID);  
					$link .='" title= "Go to the section">Clicca</a>';
					echo $link;

				?>
				</div><!-- .entry-content -->
			</article><!-- #post-## -->
		
		<?php
			endwhile;
		wp_reset_query();
		?>
			<?php
					
				endif;
			?>
		</div><!-- #content -->
	</section><!-- #primary -->
<?php get_footer(); ?>