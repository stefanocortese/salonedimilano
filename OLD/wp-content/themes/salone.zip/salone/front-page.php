<?php
/**
 * The frontpage template file
 * @package WordPress
 * @subpackage Salone_Milano
 * @since Salone Milano 1.0
 */

get_header(); ?>

<div id="main-content" class="main-content">

<?php
	if ( is_front_page()) {?>
		<div id="featured-content" class="featured-content">
	<div class="featured-content-inner">
	<?php
		/**
		 *
		 * @since Salone Milano 1.0
		 */
		//do_action( 'salone_featured_posts_before' );

		// RECUPERO L'IMMAGINE IN EVIDENZA DELLE PAGINE E LA STAMPO NELLO SLIDER FILTRANDO PER CUSTOM_FIELD = SLIDER

		$featured_posts = get_pages(array('sort_column'=>'menu_order', 'sort_order' => 'ASC','meta_value' => 'slider', 'post-type' => 'page'));

		foreach ( (array) $featured_posts as $order => $post ) :
			setup_postdata( $post );

			?>

			<article <?php post_class(); ?>>
				
				<?php
					// Output the featured image.
					if ( has_post_thumbnail() ) :
						
							the_post_thumbnail( 'salone-bg' );
				?>		
					
				
				<header class="entry-header">
				<h1 ><?php the_field('titolo-canvas'); ?></h1>
				  <p><?php the_field('sottotitolo-canvas'); ?></p>
					<a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark"><?php the_field('pulsante-canvas') ?></a> 
				</header><!-- .entry-header -->

				<?php
					endif;
				?>

			</article><!-- #post-## -->
		
		<?php
			
		endforeach;

		/**
		 * Fires after the Salone Milano featured content.
		 *
		 * @since Salone Milano 1.0
		 */
		//do_action( 'salone_featured_posts_after' );

		wp_reset_postdata();
	?>
	</div><!-- .featured-content-inner -->
</div><!-- #featured-content .featured-content -->
<?php
	}
?>

</div><!-- #main-content -->

<?php
get_footer();
