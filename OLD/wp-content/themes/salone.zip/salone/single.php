<?php
/**
 * The Template for displaying all single posts
 *
 * @package WordPress
 * @subpackage Salone_Milano
 * @since Salone Milano 1.0
 */


get_header(); ?>

	<div id="primary" class="site-content">
		<div id="content" role="main">

			<?php while ( have_posts() ) : the_post(); ?>

			<?php

			//RECUPERO IL NOME DEL CUSTOM POST DI APPARTENENZA 

			 $post_type = get_post_type_object( get_post_type($post) );
				//STAMPO IL NOME DELLA SEZIONE (CARING, COLOR, STRAIGHTNESS)
				echo $cpt = $post_type->label ;

			?>

			<?php 
			
			//RECUPERO LA CATEGORIA (GAMMA) DI APPARTENENZA
			if (get_the_terms($post->ID,  $post_type->label.'-line')) {
			  $taxonomy_ar = get_the_terms($post->ID,  $post_type->label.'-line');

			  foreach ($taxonomy_ar as $taxonomy_term) {
			    $output =  $taxonomy_term->name ;
			  }
			  //STAMPO IL NOME DELLA GAMMA (CATEGORIA)
			  echo $output;
			}

			?>
		

				<article id="post-<?php the_title(); ?>" <?php post_class(); ?>>
				<?php

					$image = get_field('immagine_prodotto'); 
			
				?>

				<img src="<?php echo $image[url]; ?>" alt="<?php the_title(); ?>" class="bg">

					<header class="entry-header">

						<h1 class="entry-title">

						<?php the_field('titolo_prodotto'); ?>
						
						</h1>

					</header><!-- .entry-header -->

					<div class="entry-content">
						
					<?php 

						the_field('sottotitolo_prodotto');

					?>
					</div><!-- .entry-content -->

					<div class="extras">

					<?php

					//Verifico che ci siano Benefici e Kit Composition

						function exist_ACF_group_by_title($title_str) {
						global $wpdb;
						return $wpdb->get_row("SELECT * FROM wp_posts WHERE  post_status = 'publish' && post_type = 'acf-field-group' && post_title = '" . $title_str . "'", 'ARRAY_A');
						}

						$tot_span = 12;


						function count_group_fields($tot_span){

							$tot_el = array();


							if(exist_ACF_group_by_title('Benefit 1') && get_field('titolo_benefit_1')!=""){

								array_push($tot_el, 'benefit_1');

							}

							if(exist_ACF_group_by_title('Benefit 2')&& get_field('titolo_benefit_2')!=""){
								
								array_push($tot_el, 'benefit_2');

							}

							if(exist_ACF_group_by_title('Kit composition')&& get_field('titolo_kit')!=""){

								array_push($tot_el, 'kit');


							}

							$elements = count($tot_el);

							$col_span = $tot_span / $elements;

							foreach ($tot_el as $element) {
							?>
								<div class="span<?php echo $col_span; ?>">

							<?php

								if(get_field('titolo_'.$element.'')){

								$tit = '<div class="benefit-title">';
								$tit .= get_field('titolo_'.$element.'');
								$tit .= '</div>';
								echo $tit;

								}
								if(get_field('sottotitolo_'.$element.'')){

								$sottotit  = '<div class="benefit-paragraph">';
								$sottotit .= get_field('sottotitolo_'.$element.'');
								$sottotit .= '</div>';
								echo $sottotit;

								}

								if(get_field('immagine_'.$element.'')){
								$image = get_field('immagine_'.$element.'');

								$img_bg = '<img class="benefit-bg" src="';
								$img_bg .= $image['url'];
								$img_bg .= ' " >';
								echo $img_bg;
								
								}

							?>

								</div>
							<?php
							}
						
						}

						echo count_group_fields($tot_span);
						
						?>

					</div>


				</article><!-- #post-## -->

				<nav class="nav-single">

					<?php

					//NAV TRA I PRODOTTI DELLA STESSA GAMMA (CATEGORIA)

					$postlist_args = array(
					   'posts_per_page'  => -1,
					   'orderby'         => 'menu_order',
					   'order'           => 'ASC',
					   'post_type'       => $cpt,
					   $cpt.'-line'      => $output
					); 
					$postlist = get_posts( $postlist_args );

					// get ids of posts retrieved from get_posts
					$ids = array();
					foreach ($postlist as $thepost) {
					   $ids[] = $thepost->ID;
					}

					// get and echo previous and next post in the same taxonomy        
					$thisindex = array_search($post->ID, $ids);
					$previd = $ids[$thisindex-1];
					$nextid = $ids[$thisindex+1];
					if ( !empty($previd) ) {
					   echo '<a rel="prev" href="' . get_permalink($previd). '">previous</a>';
					}
					if ( !empty($nextid) ) {
					   echo '<a rel="next" href="' . get_permalink($nextid). '">next</a>';
					}

					?>


				</nav><!-- .nav-single -->


			<?php endwhile; // end of the loop. ?>

		</div><!-- #content -->
	</div><!-- #primary -->
<?php get_footer(); ?>